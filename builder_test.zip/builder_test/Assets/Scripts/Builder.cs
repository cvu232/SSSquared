﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Builder : MonoBehaviour
{
    public BlockGrid grid;

    public BlockBase block;

    public Button BuildButton;

    public bool buildingMode = false;

    // active block //
    public BlockBase workingBlock;


    void Start()
    {
        BuildButton.onClick.AddListener(InsertBlock);
    }

    void Update()
    {
        if (buildingMode && workingBlock != null)
        {
            // while block is in building state
            if (workingBlock.isBuildHolo)
            {
                //workingBlock.followMouse();

                // snap block to grid //
                //Debug.Log("block: " + workingBlock.transform.position);
                workingBlock.transform.position = grid.GetNearestPointOnGrid(Global.worldMouse);
                //Debug.Log("Mouse: " + Global.worldMouse);


                // left-click build in valid space//
                if (Input.GetMouseButtonDown(0) && !workingBlock.inBadSpace)
                {
                    workingBlock.transform.position = grid.GetNearestPointOnGrid(Global.worldMouse);
                    workingBlock.build();
                    BuildingModeOff();
                }
            }
        }
    }

    public void InsertBlock()
    {
        // create a new block at mouse pos //
        workingBlock = Instantiate(block, Vector3.zero, Quaternion.identity);
        BuildingModeOn();
    }

    private void BuildingModeOn()
    {
        workingBlock.isBuildHolo = true; // set block to holo
        buildingMode = true;
    }

    private void BuildingModeOff()
    {
        workingBlock = null; // detach //
        buildingMode = false;
    }

    public void RemoveBlock()
    {

    }

}
