﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Global : MonoBehaviour
{
    public static Vector3 worldMouse;

    // Update is called once per frame
    void Update()
    {
        calcWorldMouse();
    }

    // calculate "mouse" in world space //
    private void calcWorldMouse()
    {
        Plane plane = new Plane(Vector3.forward, 0);

        float distance;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (plane.Raycast(ray, out distance))
        {
            worldMouse = ray.GetPoint(distance);
        }
    }
}
