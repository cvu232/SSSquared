﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockBase : MonoBehaviour
{
    public bool isBuildHolo; // is build state
    public bool inBadSpace; // is in invalid build space
    public bool isPlaced;

    public Rigidbody rigidBody;
    public MeshRenderer meshRenderer;

    public Material material;
    public Material holo;

    private void Start()
    {
        rigidBody = GetComponent<Rigidbody>();
        meshRenderer = GetComponent<MeshRenderer>();
        material = meshRenderer.material;
        isBuildHolo = false;
        inBadSpace = false;
        isBuildHolo = true;
        isPlaced = false;
        rigidBody.freezeRotation = true;
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("solid") && !isPlaced)
        {
            inBadSpace = true;
            meshRenderer.material = holo;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("solid") && !isPlaced)
        {
            inBadSpace = false;
            meshRenderer.material = material;
        }
    }

    public void build()
    {
        isBuildHolo = false;
        isPlaced = true;
    }

    public void followMouse()
    {
        transform.position = Global.worldMouse;
    }

    // delete the game object
    public void delete()
    {
        Destroy(this.gameObject);
    }


}
